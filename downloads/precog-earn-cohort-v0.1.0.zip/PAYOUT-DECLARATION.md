DECLARE YOUR PAYOUT ADDRESS — ONE PAGE
======================================
Send ONE email to timlangeveldt@gmail.com with subject:
"PreCog Earn cohort - declaration"

Body template (free text accepted; this is just the shape):

    handle: h_<the string from companions/desktop/.runtime/identity.txt>
    xmr address: <your Monero standard address, 95 chars, starts with 4>
    minimum payout: <credits; default 100>
    full name (optional; for invoice routing only):
    country (optional; for payout routing):

WHAT HAPPENS WITH YOUR DATA
  - The address goes into the operator-controlled payout_addresses table
    and is used ONLY to settle redemptions. It is not published as yours.
  - You may ask for it to be deleted at any time; outstanding credits are
    settled or refunded per the active payout policy, then the mapping is
    dropped.

WHAT WE WILL NEVER DO
  - Ask for your wallet seed phrase or private keys. Ever.
  - Move treasury funds without a human-signed settlement.
  - Share or sell your handle-to-address association. Ever.

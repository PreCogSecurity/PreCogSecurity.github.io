COHORT FAQ
==========

Q: How much will this pay me?
A: Nowhere near enough to quit your job. ~170 H/s per 3 threads on a
   2012 i7-class CPU. Participating is about proving the economics and
   hardening the ledger — not about revenue.

Q: Can I game it?
A: Receipts are node-signed claims of pool-accepted shares. Invalid shares
   earn zero. Duplicates are rejected at insert. The operator reconciles
   before settlement and disputes clear lazily with the chain. Don't.

Q: What if my node dies mid-session?
A: Shares already redeemed by the pool are already counted. Session
   receipts flush at session end; crash before flush = those shares are
   lost, no harm done.

Q: Who decides payouts?
A: A human. Proportional to outstanding credits at settlement, every send
   reviewed and signed by the operator. Nobody is paid by an algorithm
   acting alone, and nobody is paid by accident.

Q: What if PreCog disappears?
A: The ledger is append-only and exportable, and the desktop node is open
   source (GPL-3.0). Any fork can reconstruct the accounting. Your electricity
   is the only real cost you carry.

Q: I want to build the companion apps with you.
A: Email us. The Android skeleton is consent-first already; PRs welcome.

Q: Why Monero / RandomX?
A: ASIC-resistant CPU mining — your desktop isn't competing with warehouse
   ASICs. Yes, it earns less per watt than logging. That is the deal, in
   exchange for no specialization.

YOUR IDENTITY ON THE LEDGER — HOW THIS WORKS
=============================================
- The node creates a random pseudonymous handle on first run
  (h_<32 hex chars). It is stored in companions/desktop/.runtime/identity.txt
  on your machine. It is NOT your wallet address. It is NOT your name.
- Every share your node submits is recorded against your handle on the
  append-only ledger (the precog-earn-payout D1 on Cloudflare, published on
  request for audit). Duplicate receipts are rejected. Balances are
  recomputed from the chain — there is no mutable counter to game.
- We CHOOSE NOT to link your handle to your legal identity. If you declare
  an XMR payout address + a correspondence email, we map your handle to
  that address in the operator-controlled payout_addresses table. That
  mapping is revealed only to: you, and the operator. Not advertisers.
  Not brokers. Nobody else.
- Lose identity.txt and your handle loses its accumulated balance. Keep a
  copy in a password manager if you are joining for payout.

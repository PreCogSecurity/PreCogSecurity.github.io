# PreCog Earn Desktop v0.1.2

Consent-first Monero miner. A small Python wrapper around a pinned, SHA-256
verified XMRig build. It does not hide, persist, or self-install anything: the
miner runs while the window is open and stops when you stop it or close it.

## Files in this download

| File | Purpose |
|---|---|
| `earn.bat` | Double-click launcher for Windows (runs the GUI). |
| `precog-earn-gui.py` | Tkinter window: consent checkbox, Start/Stop, hashrate, destination wallet, log. |
| `precog-earn-node.py` | The node itself: consent gate, pinned XMRig download + hash check, pool connection, ledger line. |
| `precog-earn-wallet.txt` | Destination XMR address (one line). Replace with your own to be paid directly. |
| `THIRD_PARTY.md` | Licence and provenance notes for XMRig. |

## Run it

```
python precog-earn-node.py --i-consent --start --wallet <YOUR_XMR_ADDRESS>
```

Precedence for the destination address: `--wallet`, then `PRECOG_XMR_WALLET`,
then `precog-earn-wallet.txt`. The app prints the destination prefix on start so
the payout target is never ambiguous. A blocked (compromised or retired)
address is refused outright with exit code 3.

## Getting paid

Mining goes to a public pool (`stratum+ssl://pool.supportxmr.com:443`). The pool
verifies shares and pays the destination wallet directly when that wallet reaches
the pool's payout threshold. PreCog never holds your coins and there are no
credits or points in this build. Your realised amount depends on hashrate,
network difficulty, and the pool's threshold - not on anything this app promises.

## Updates

```
python precog-earn-node.py --check-update
```

Checks the update manifest first, GitHub releases second, and only reports. It
never installs anything by itself.

## Honest limits

- CPU mining on a laptop means small amounts; electricity can exceed the payout.
- Huge pages / MSR tuning needs elevated rights and BIOS support; without them
  hashrate is lower but the miner still works.
- No GPU acceleration is shipped in this build (OpenCL/CUDA are disabled in the
  pinned binary configuration used here).

## Licence

Wrapper code: as published in the PreCogSecurity repository. XMRig is GPL-3.0;
see `THIRD_PARTY.md`.
